import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, formatDistanceToNow } from 'date-fns'
import type { BadgeStatus, ManuscriptStage, PaymentStatus } from '@/types'

export const cn = (...inputs: ClassValue[]) => twMerge(clsx(inputs))

export const formatCurrency = (amount: number) =>
  `৳ ${Number(amount).toLocaleString('en-BD')}`

export const formatDate = (d: string | Date) =>
  format(new Date(d), 'dd MMM yyyy')

export const formatRelative = (d: string | Date) =>
  formatDistanceToNow(new Date(d), { addSuffix: true })

export const STAGE_LABELS: Record<ManuscriptStage, string> = {
  submitted:    'জমা দেওয়া হয়েছে',
  under_review: 'পর্যালোচনাধীন',
  editing:      'সম্পাদনা',
  design:       'ডিজাইন',
  printing:     'মুদ্রণ',
  published:    'প্রকাশিত',
}

export const STAGE_COLORS: Record<ManuscriptStage, string> = {
  submitted:    'bg-blue-100 text-blue-800',
  under_review: 'bg-amber-100 text-amber-800',
  editing:      'bg-pink-100 text-pink-800',
  design:       'bg-green-100 text-green-800',
  printing:     'bg-yellow-100 text-yellow-800',
  published:    'bg-emerald-100 text-emerald-800',
}

export const BADGE_LABELS: Record<BadgeStatus, string> = {
  unverified: 'অযাচাইকৃত',
  active:     'সক্রিয়',
  verified:   'যাচাইকৃত ⭐',
}

export const BADGE_COLORS: Record<BadgeStatus, string> = {
  unverified: 'bg-gray-100 text-gray-600',
  active:     'bg-teal-100 text-teal-800',
  verified:   'bg-amber-100 text-amber-800',
}

export const PAYMENT_LABELS: Record<PaymentStatus, string> = {
  pending: 'বকেয়া',
  partial: 'আংশিক',
  paid:    'পরিশোধিত',
}

export const PAYMENT_COLORS: Record<PaymentStatus, string> = {
  pending: 'bg-red-100 text-red-800',
  partial: 'bg-orange-100 text-orange-800',
  paid:    'bg-green-100 text-green-800',
}

export const STAGE_ORDER: ManuscriptStage[] = [
  'submitted', 'under_review', 'editing', 'design', 'printing', 'published',
]
