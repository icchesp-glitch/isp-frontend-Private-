import Cookies from 'js-cookie'

const COOKIE_OPTS = { expires: 1, sameSite: 'lax' as const }

export const setAdminAuth = (token: string, user: any) => {
  Cookies.set('isp_token', token, COOKIE_OPTS)
  Cookies.set('isp_user', JSON.stringify(user), COOKIE_OPTS)
  Cookies.set('isp_role', 'admin', COOKIE_OPTS)
}

export const setAuthorAuth = (token: string, author: any) => {
  Cookies.set('isp_token', token, COOKIE_OPTS)
  Cookies.set('isp_user', JSON.stringify(author), COOKIE_OPTS)
  Cookies.set('isp_role', 'author', COOKIE_OPTS)
}

export const getUser = () => {
  try {
    const raw = Cookies.get('isp_user')
    return raw ? JSON.parse(raw) : null
  } catch { return null }
}

export const getRole = () => Cookies.get('isp_role')
export const getToken = () => Cookies.get('isp_token')
export const isLoggedIn = () => !!Cookies.get('isp_token')

export const logout = () => {
  Cookies.remove('isp_token')
  Cookies.remove('isp_user')
  Cookies.remove('isp_role')
}
