'use client'
import { useState, useEffect, useCallback } from 'react'
import { get, post, patch } from './api'
import type { Author, Manuscript, Invoice, FinancialRecord, DashboardStats, PipelineCounts } from '@/types'

// Generic fetch hook
export function useFetch<T>(url: string, params?: any) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetch = useCallback(async () => {
    try {
      setLoading(true)
      const result = await get<T>(url, params)
      setData(result)
    } catch (e: any) {
      setError(e.response?.data?.message || 'Error loading data')
    } finally {
      setLoading(false)
    }
  }, [url, JSON.stringify(params)])

  useEffect(() => { fetch() }, [fetch])
  return { data, loading, error, refetch: fetch }
}

// Authors
export const useAuthors = (params?: any) =>
  useFetch<{ authors: Author[]; total: number }>('/authors', params)

export const useAuthor = (id: string) =>
  useFetch<Author>(`/authors/${id}`)

// Manuscripts
export const useManuscripts = (params?: any) =>
  useFetch<{ manuscripts: Manuscript[]; total: number }>('/manuscripts', params)

export const useManuscript = (id: string) =>
  useFetch<Manuscript>(`/manuscripts/${id}`)

export const usePipeline = () =>
  useFetch<Record<string, Manuscript[]>>('/manuscripts/pipeline')

export const useDelayed = () =>
  useFetch<any[]>('/manuscripts/delayed')

// Invoices
export const useInvoices = (params?: any) =>
  useFetch<{ invoices: Invoice[]; total: number }>('/invoices', params)

export const useInvoice = (id: string) =>
  useFetch<Invoice>(`/invoices/${id}`)

export const usePendingInvoices = () =>
  useFetch<Invoice[]>('/invoices/pending')

// Financials
export const useFinancials = (params?: any) =>
  useFetch<{ records: FinancialRecord[] }>('/financials', params)

export const useFinancialOverview = () =>
  useFetch<any>('/financials/overview')

// Dashboard
export const useAdminDashboard = () =>
  useFetch<DashboardStats>('/dashboard/admin')

export const usePipelineCounts = () =>
  useFetch<PipelineCounts>('/dashboard/pipeline')

export const useAlerts = () =>
  useFetch<{ delayed: any[]; count: number }>('/dashboard/alerts')

export const useAuthorDashboard = () =>
  useFetch<any>('/dashboard/author')
