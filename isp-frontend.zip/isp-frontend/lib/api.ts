import axios from 'axios'
import Cookies from 'js-cookie'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: { 'Content-Type': 'application/json' },
})

// Attach token automatically
api.interceptors.request.use((config) => {
  const token = Cookies.get('isp_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Handle 401
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      Cookies.remove('isp_token')
      Cookies.remove('isp_user')
      if (typeof window !== 'undefined') {
        const isPortal = window.location.pathname.startsWith('/portal')
        window.location.href = isPortal ? '/portal/login' : '/admin/login'
      }
    }
    return Promise.reject(err)
  },
)

// Unwrap .data.data from ApiResponse wrapper
export const get = async <T>(url: string, params?: any): Promise<T> => {
  const res = await api.get(url, { params })
  return res.data.data ?? res.data
}

export const post = async <T>(url: string, body?: any): Promise<T> => {
  const res = await api.post(url, body)
  return res.data.data ?? res.data
}

export const patch = async <T>(url: string, body?: any): Promise<T> => {
  const res = await api.patch(url, body)
  return res.data.data ?? res.data
}

export const del = async <T>(url: string): Promise<T> => {
  const res = await api.delete(url)
  return res.data.data ?? res.data
}

export const uploadFile = async (url: string, file: File): Promise<any> => {
  const form = new FormData()
  form.append('file', file)
  const res = await api.post(url, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return res.data.data ?? res.data
}
