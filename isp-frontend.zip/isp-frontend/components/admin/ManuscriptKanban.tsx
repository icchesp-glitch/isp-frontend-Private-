'use client'
import Link from 'next/link'
import { StageBadge } from '@/components/shared/Badge'
import { formatRelative } from '@/lib/utils'
import type { Manuscript, ManuscriptStage } from '@/types'

const COLUMNS: { stage: ManuscriptStage; label: string; emoji: string; color: string }[] = [
  { stage: 'submitted',    label: 'জমা দেওয়া',    emoji: '📥', color: 'border-blue-200 bg-blue-50' },
  { stage: 'under_review', label: 'পর্যালোচনা',    emoji: '🔍', color: 'border-amber-200 bg-amber-50' },
  { stage: 'editing',      label: 'সম্পাদনা',      emoji: '✏️', color: 'border-pink-200 bg-pink-50' },
  { stage: 'design',       label: 'ডিজাইন',         emoji: '🎨', color: 'border-green-200 bg-green-50' },
  { stage: 'printing',     label: 'মুদ্রণ',          emoji: '🖨️', color: 'border-yellow-200 bg-yellow-50' },
  { stage: 'published',    label: 'প্রকাশিত',       emoji: '📗', color: 'border-emerald-200 bg-emerald-50' },
]

export default function ManuscriptKanban({ pipeline }: { pipeline: Record<string, Manuscript[]> }) {
  return (
    <div className="grid grid-cols-6 gap-3 min-w-[900px]">
      {COLUMNS.map(({ stage, label, emoji, color }) => {
        const items = pipeline[stage] || []
        return (
          <div key={stage} className={`rounded-lg border-2 ${color} flex flex-col`}>
            <div className="p-3 border-b border-white/50">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-ink">{emoji} {label}</span>
                <span className="text-xs font-mono bg-white/80 px-2 py-0.5 rounded-full font-bold">
                  {items.length}
                </span>
              </div>
            </div>
            <div className="p-2 space-y-2 flex-1 overflow-y-auto max-h-[500px]">
              {items.length === 0 && (
                <p className="text-muted text-xs text-center py-4 opacity-60">খালি</p>
              )}
              {items.map((m) => (
                <Link key={m.id} href={`/admin/manuscripts/${m.id}`}>
                  <div className="bg-white border border-border/60 rounded-lg p-3 cursor-pointer hover:shadow-md hover:border-gold transition-all">
                    <p className="text-xs font-bold text-ink line-clamp-2 leading-tight">{m.title}</p>
                    <p className="text-xs text-muted mt-1">{m.author?.authorCode} · {m.author?.fullName}</p>
                    <p className="text-xs text-muted/60 mt-1 font-mono">{formatRelative(m.updatedAt)}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}
