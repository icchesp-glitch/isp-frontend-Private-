'use client'
import { formatDate } from '@/lib/utils'
import { STAGE_LABELS } from '@/lib/utils'
import type { StageLog } from '@/types'

export default function StageTimeline({ logs }: { logs: StageLog[] }) {
  if (!logs?.length) return <p className="text-muted text-sm">কোনো স্টেজ লগ নেই।</p>

  return (
    <div className="relative">
      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border" />
      <div className="space-y-4">
        {logs.map((log, i) => (
          <div key={log.id} className="relative flex gap-4 pl-10 animate-slide-up" style={{ animationDelay: `${i * 50}ms`, opacity: 0 }}>
            <div className={`absolute left-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 border-white z-10 ${
              log.toStage === 'published' ? 'bg-emerald-500 text-white' : 'bg-[#0f0e0c] text-[#e8c76a]'
            }`}>
              {i + 1}
            </div>
            <div className="card p-3 flex-1">
              <div className="flex items-start justify-between gap-2">
                <div>
                  {log.fromStage && (
                    <span className="text-muted text-xs">
                      {STAGE_LABELS[log.fromStage]} →{' '}
                    </span>
                  )}
                  <span className="text-sm font-bold text-ink">
                    {STAGE_LABELS[log.toStage]}
                  </span>
                </div>
                <span className="text-muted text-xs font-mono whitespace-nowrap">
                  {formatDate(log.createdAt)}
                </span>
              </div>
              {log.comment && (
                <p className="text-muted text-xs mt-1.5 bg-paper rounded px-2 py-1">
                  {log.comment}
                </p>
              )}
              {log.changedBy && (
                <p className="text-xs text-muted mt-1">— {log.changedBy.name}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
