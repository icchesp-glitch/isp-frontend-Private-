import { formatCurrency } from '@/lib/utils'
import type { FinancialRecord } from '@/types'

export default function FinancialCard({ record }: { record: FinancialRecord }) {
  const balance = Number(record.balanceDue)
  return (
    <div className="card p-5">
      <h3 className="text-xs font-mono uppercase tracking-wider text-muted mb-4">আর্থিক সারসংক্ষেপ</h3>
      <div className="space-y-3">
        <Row label="মোট চুক্তি" value={formatCurrency(record.totalDeal)} />
        <Row label="অগ্রিম পরিশোধ" value={formatCurrency(record.advancePaid)} color="text-teal" />
        <Row label="কর্তন" value={formatCurrency(record.deductions)} color="text-rust" />
        <div className="border-t border-border pt-3">
          <Row
            label="বকেয়া ব্যালেন্স"
            value={formatCurrency(Math.abs(balance))}
            color={balance > 0 ? 'text-rust font-bold' : balance < 0 ? 'text-teal font-bold' : 'text-ink'}
            note={balance < 0 ? '(প্রকাশক দেবেন)' : balance > 0 ? '(লেখক দেবেন)' : '(নিষ্পত্তি)'}
          />
        </div>
      </div>
      {record.notes && (
        <p className="text-xs text-muted mt-4 bg-paper rounded px-3 py-2">{record.notes}</p>
      )}
    </div>
  )
}

function Row({ label, value, color = 'text-ink', note }: { label: string; value: string; color?: string; note?: string }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-sm text-muted">{label}</span>
      <div className="text-right">
        <span className={`text-sm font-semibold font-mono ${color}`}>{value}</span>
        {note && <span className="text-xs text-muted ml-1">{note}</span>}
      </div>
    </div>
  )
}
