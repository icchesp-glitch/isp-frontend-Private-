export default function LoadingSpinner({ text = 'লোড হচ্ছে...' }: { text?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="w-8 h-8 border-2 border-border border-t-gold rounded-full animate-spin" />
      <p className="text-muted text-sm font-mono">{text}</p>
    </div>
  )
}
