'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { logout, getUser } from '@/lib/auth'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, Users, BookOpen, FileText,
  DollarSign, LogOut, BookMarked, AlertTriangle
} from 'lucide-react'

const NAV = [
  { href: '/admin/dashboard',    label: 'ড্যাশবোর্ড',    icon: LayoutDashboard },
  { href: '/admin/authors',      label: 'লেখকবৃন্দ',      icon: Users },
  { href: '/admin/manuscripts',  label: 'পাণ্ডুলিপি',     icon: BookOpen },
  { href: '/admin/manuscripts/pipeline', label: 'পাইপলাইন', icon: BookMarked },
  { href: '/admin/invoices',     label: 'ইনভয়েস',         icon: FileText },
  { href: '/admin/financials',   label: 'আর্থিক',          icon: DollarSign },
]

export default function Sidebar() {
  const path = usePathname()
  const router = useRouter()
  const user = getUser()

  const handleLogout = () => {
    logout()
    router.push('/admin/login')
  }

  return (
    <aside className="w-64 bg-[#0f0e0c] flex flex-col h-screen sticky top-0 shrink-0">
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <div className="text-[#e8c76a] font-display text-lg font-bold leading-tight">
          ইচ্ছে স্বপ্ন
        </div>
        <div className="text-white/40 text-xs font-mono mt-1 tracking-widest uppercase">
          প্রকাশনী OS
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {NAV.map(({ href, label, icon: Icon }) => {
          const active = path === href || (href !== '/admin/dashboard' && path.startsWith(href))
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all',
                active
                  ? 'bg-[#c9973a] text-[#0f0e0c] font-bold'
                  : 'text-white/60 hover:text-white hover:bg-white/8'
              )}
            >
              <Icon size={16} />
              {label}
            </Link>
          )
        })}
      </nav>

      {/* User */}
      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-3 mb-3 px-2">
          <div className="w-8 h-8 rounded-full bg-[#c9973a] flex items-center justify-center text-[#0f0e0c] font-bold text-sm">
            {user?.name?.[0] || 'A'}
          </div>
          <div>
            <div className="text-white text-xs font-semibold truncate w-32">{user?.name || 'Admin'}</div>
            <div className="text-white/40 text-xs font-mono">{user?.role}</div>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-white/50 hover:text-white hover:bg-white/8 text-sm transition-all"
        >
          <LogOut size={15} />
          লগআউট
        </button>
      </div>
    </aside>
  )
}
