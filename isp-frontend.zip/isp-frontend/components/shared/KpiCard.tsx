import { cn } from '@/lib/utils'

interface Props {
  label: string
  value: string | number
  sub?: string
  icon?: string
  color?: 'gold' | 'teal' | 'rust' | 'default'
  delay?: number
}

const COLOR_MAP = {
  gold:    'border-gold bg-amber-50',
  teal:    'border-teal bg-teal-50',
  rust:    'border-rust bg-red-50',
  default: 'border-border bg-white',
}

export default function KpiCard({ label, value, sub, icon, color = 'default', delay = 0 }: Props) {
  return (
    <div
      className={cn('card p-5 animate-slide-up border-l-4', COLOR_MAP[color])}
      style={{ animationDelay: `${delay}ms`, opacity: 0 }}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-muted text-xs font-mono uppercase tracking-wider">{label}</p>
          <p className="text-2xl font-bold text-ink mt-1 font-display">{value}</p>
          {sub && <p className="text-muted text-xs mt-1">{sub}</p>}
        </div>
        {icon && <span className="text-3xl opacity-60">{icon}</span>}
      </div>
    </div>
  )
}
