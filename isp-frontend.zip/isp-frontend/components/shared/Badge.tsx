import { cn } from '@/lib/utils'
import {
  BADGE_LABELS, BADGE_COLORS,
  STAGE_LABELS, STAGE_COLORS,
  PAYMENT_LABELS, PAYMENT_COLORS,
} from '@/lib/utils'
import type { BadgeStatus, ManuscriptStage, PaymentStatus } from '@/types'

export function AuthorBadge({ status }: { status: BadgeStatus }) {
  return (
    <span className={cn('badge', BADGE_COLORS[status])}>
      {BADGE_LABELS[status]}
    </span>
  )
}

export function StageBadge({ stage }: { stage: ManuscriptStage }) {
  return (
    <span className={cn('badge', STAGE_COLORS[stage])}>
      {STAGE_LABELS[stage]}
    </span>
  )
}

export function PaymentBadge({ status }: { status: PaymentStatus }) {
  return (
    <span className={cn('badge', PAYMENT_COLORS[status])}>
      {PAYMENT_LABELS[status]}
    </span>
  )
}
