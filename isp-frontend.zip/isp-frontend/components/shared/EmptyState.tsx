interface Props { icon?: string; title: string; subtitle?: string; action?: React.ReactNode }
export default function EmptyState({ icon = '📭', title, subtitle, action }: Props) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3 text-center">
      <div className="text-5xl opacity-40">{icon}</div>
      <h3 className="font-semibold text-ink text-lg">{title}</h3>
      {subtitle && <p className="text-muted text-sm max-w-xs">{subtitle}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}
