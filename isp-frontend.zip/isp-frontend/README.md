# ইচ্ছে স্বপ্ন প্রকাশনী — Frontend

Next.js 14 (App Router) frontend for the Publishing OS.

## Quick Start

```bash
npm install
cp .env.local.example .env.local
# Edit .env.local → set NEXT_PUBLIC_API_URL
npm run dev
```

App runs at: http://localhost:3000

## Default Routes

| Route | Description |
|---|---|
| `/admin/login` | Admin login |
| `/admin/dashboard` | Admin overview + KPIs |
| `/admin/authors` | Author list + create |
| `/admin/authors/[id]` | Author detail + badge + portal |
| `/admin/manuscripts` | Manuscript list |
| `/admin/manuscripts/pipeline` | Kanban pipeline view |
| `/admin/manuscripts/[id]` | Detail + stage advance + upload |
| `/admin/invoices` | Invoice list + create |
| `/admin/invoices/[id]` | Invoice detail + payment update |
| `/admin/financials` | Financial records overview |
| `/portal/login` | Author portal login |
| `/portal/dashboard` | Author home |
| `/portal/dashboard/manuscripts` | Author's manuscripts + timeline |
| `/portal/dashboard/financials` | Author's financial view |
| `/portal/dashboard/invoices` | Author's invoices + PDF download |

## Design System

- **Colors:** ink `#0f0e0c`, paper `#f5f0e8`, gold `#c9973a`, teal `#1a6b6b`, rust `#b5451b`
- **Fonts:** Hind Siliguri (Bengali UI), Playfair Display (headings), JetBrains Mono (codes)
- **Components:** card, badge, btn-primary, btn-gold, btn-ghost, input, field-label

## Stack

- Next.js 14 App Router
- Tailwind CSS
- Axios (API calls)
- js-cookie (JWT storage)
- react-hot-toast (notifications)
- lucide-react (icons)
- date-fns (date formatting)

## Environment Variables

```
NEXT_PUBLIC_API_URL=http://localhost:3001
NEXT_PUBLIC_APP_NAME=ইচ্ছে স্বপ্ন প্রকাশনী
```

## Deployment (Vercel)

1. Push to GitHub
2. Import in Vercel
3. Set `NEXT_PUBLIC_API_URL` to your deployed backend URL
4. Deploy
