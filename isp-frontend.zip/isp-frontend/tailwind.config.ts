import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        hind: ['var(--font-hind)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
        display: ['var(--font-display)', 'serif'],
      },
      colors: {
        ink:    '#0f0e0c',
        paper:  '#f5f0e8',
        aged:   '#e8e0cc',
        gold:   '#c9973a',
        'gold-light': '#e8c76a',
        rust:   '#b5451b',
        teal:   '#1a6b6b',
        'teal-light': '#2a9a8a',
        muted:  '#7a7060',
        border: '#c8b898',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease forwards',
        'slide-up': 'slideUp 0.4s ease forwards',
        'pulse-gold': 'pulseGold 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        slideUp: { from: { opacity: '0', transform: 'translateY(12px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        pulseGold: { '0%,100%': { boxShadow: '0 0 0 0 rgba(201,151,58,0.4)' }, '50%': { boxShadow: '0 0 0 8px rgba(201,151,58,0)' } },
      },
    },
  },
  plugins: [],
}
export default config
