// ── Core Types ──────────────────────────────────────────────

export type BadgeStatus = 'unverified' | 'active' | 'verified'
export type ManuscriptStage = 'submitted' | 'under_review' | 'editing' | 'design' | 'printing' | 'published'
export type PaymentStatus = 'pending' | 'partial' | 'paid'
export type AdminRole = 'super_admin' | 'admin' | 'editor' | 'finance'
export type TransactionType = 'advance' | 'deduction' | 'payment' | 'refund'

export interface Author {
  id: string
  authorCode: string
  fullName: string
  email: string
  phone?: string
  address?: string
  nid?: string
  photoUrl?: string
  badgeStatus: BadgeStatus
  isActive: boolean
  portalAccess: boolean
  createdAt: string
  updatedAt: string
  _count?: { manuscripts: number; invoices: number }
  manuscripts?: Manuscript[]
}

export interface Manuscript {
  id: string
  authorId: string
  title: string
  genre?: string
  synopsis?: string
  fileUrl?: string
  fileType?: string
  currentStage: ManuscriptStage
  isPublished: boolean
  publicationDate?: string
  isbn?: string
  createdAt: string
  updatedAt: string
  author?: Pick<Author, 'authorCode' | 'fullName'>
  stageLogs?: StageLog[]
}

export interface StageLog {
  id: string
  manuscriptId: string
  fromStage?: ManuscriptStage
  toStage: ManuscriptStage
  changedBy?: { name: string }
  comment?: string
  createdAt: string
}

export interface FinancialRecord {
  id: string
  authorId: string
  manuscriptId?: string
  totalDeal: number
  advancePaid: number
  deductions: number
  balanceDue: number
  notes?: string
  createdAt: string
  updatedAt: string
  author?: Pick<Author, 'fullName' | 'authorCode'>
  manuscript?: Pick<Manuscript, 'title'>
  transactions?: FinancialTransaction[]
}

export interface FinancialTransaction {
  id: string
  type: TransactionType
  amount: number
  description?: string
  transactionDate: string
  createdAt: string
}

export interface Invoice {
  id: string
  invoiceNumber: string
  authorId: string
  manuscriptId?: string
  amount: number
  paymentStatus: PaymentStatus
  amountPaid: number
  dueDate?: string
  notes?: string
  pdfUrl?: string
  createdAt: string
  updatedAt: string
  author?: Pick<Author, 'fullName' | 'authorCode' | 'email'>
  manuscript?: Pick<Manuscript, 'title'>
}

export interface AdminUser {
  id: string
  name: string
  email: string
  role: AdminRole
}

export interface BadgeLog {
  id: string
  fromBadge?: BadgeStatus
  toBadge: BadgeStatus
  reason: string
  changedBy?: { name: string }
  createdAt: string
}

export interface DashboardStats {
  authors: { total: number }
  manuscripts: { total: number; published: number }
  invoices: { pending: number }
  financials: { totalReceivable: number }
  recentActivity: StageLog[]
}

export interface PipelineCounts {
  submitted: number
  under_review: number
  editing: number
  design: number
  printing: number
  published: number
}

export interface ApiResponse<T> {
  success: boolean
  data: T
  timestamp: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}
