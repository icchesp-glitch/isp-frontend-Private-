import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ইচ্ছে স্বপ্ন প্রকাশনী — Publishing OS',
  description: 'Complete publishing management system',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn">
      <body>{children}</body>
    </html>
  )
}
