'use client'
import { useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { useManuscript } from '@/lib/hooks'
import { post, patch, uploadFile } from '@/lib/api'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import PageHeader from '@/components/shared/PageHeader'
import Modal from '@/components/shared/Modal'
import StageTimeline from '@/components/admin/StageTimeline'
import FinancialCard from '@/components/admin/FinancialCard'
import { StageBadge, AuthorBadge } from '@/components/shared/Badge'
import { formatDate } from '@/lib/utils'
import { STAGE_LABELS, STAGE_ORDER } from '@/lib/utils'
import { ArrowRight, Upload, Download, ExternalLink } from 'lucide-react'
import type { ManuscriptStage } from '@/types'

export default function ManuscriptDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { data: manuscript, loading, refetch } = useManuscript(id)
  const [advModal, setAdvModal] = useState(false)
  const [comment, setComment] = useState('')
  const [advancing, setAdvancing] = useState(false)
  const [uploading, setUploading] = useState(false)

  const handleAdvance = async () => {
    setAdvancing(true)
    try {
      await post(`/manuscripts/${id}/advance`, { comment })
      toast.success('স্টেজ আপডেট হয়েছে!')
      setAdvModal(false)
      setComment('')
      refetch()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'ত্রুটি হয়েছে')
    } finally { setAdvancing(false) }
  }

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try {
      await uploadFile(`/manuscripts/${id}/upload`, file)
      toast.success('ফাইল আপলোড হয়েছে!')
      refetch()
    } catch { toast.error('আপলোড ব্যর্থ') }
    finally { setUploading(false) }
  }

  if (loading) return <LoadingSpinner />
  if (!manuscript) return <p className="text-muted">পাওয়া যায়নি।</p>

  const currentIdx = STAGE_ORDER.indexOf(manuscript.currentStage)
  const nextStage = currentIdx < STAGE_ORDER.length - 1 ? STAGE_ORDER[currentIdx + 1] : null
  const isPublished = manuscript.currentStage === 'published'

  return (
    <div className="animate-fade-in">
      <PageHeader
        title={manuscript.title}
        subtitle={`${manuscript.author?.authorCode} · ${manuscript.author?.fullName}`}
        actions={
          <div className="flex gap-2 items-center">
            {!isPublished && nextStage && (
              <button onClick={() => setAdvModal(true)} className="btn-gold">
                {STAGE_LABELS[nextStage]} →
              </button>
            )}
            {isPublished && (
              <span className="text-emerald-700 font-bold text-sm bg-emerald-100 px-4 py-2 rounded-lg">📗 প্রকাশিত</span>
            )}
          </div>
        }
      />

      {/* Stage Progress Bar */}
      <div className="card p-4 mb-6">
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          {STAGE_ORDER.map((s, i) => {
            const done = i <= currentIdx
            const current = s === manuscript.currentStage
            return (
              <div key={s} className="flex items-center gap-1 shrink-0">
                <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  current ? 'bg-gold text-ink scale-105 shadow-sm' :
                  done ? 'bg-teal text-white' : 'bg-aged text-muted'
                }`}>
                  {current && <span className="w-1.5 h-1.5 rounded-full bg-ink inline-block animate-pulse" />}
                  {STAGE_LABELS[s as ManuscriptStage]}
                </div>
                {i < STAGE_ORDER.length - 1 && (
                  <ArrowRight size={12} className={done ? 'text-teal' : 'text-border'} />
                )}
              </div>
            )
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Details */}
        <div className="space-y-4">
          <div className="card p-5">
            <h3 className="text-xs font-mono uppercase tracking-wider text-muted mb-4">বিস্তারিত</h3>
            <div className="space-y-2 text-sm">
              <InfoRow label="ঘরানা" value={manuscript.genre || '—'} />
              <InfoRow label="স্টেজ" value={<StageBadge stage={manuscript.currentStage} />} />
              <InfoRow label="তারিখ" value={formatDate(manuscript.createdAt)} />
              {manuscript.isPublished && manuscript.publicationDate && (
                <InfoRow label="প্রকাশ তারিখ" value={formatDate(manuscript.publicationDate)} />
              )}
              {manuscript.isbn && <InfoRow label="ISBN" value={manuscript.isbn} />}
            </div>
          </div>

          {/* File Upload */}
          <div className="card p-5">
            <h3 className="text-xs font-mono uppercase tracking-wider text-muted mb-3">ফাইল</h3>
            {manuscript.fileUrl ? (
              <div className="flex items-center justify-between bg-paper rounded-lg p-3 border border-border">
                <div>
                  <p className="text-xs font-bold text-ink">পাণ্ডুলিপি ফাইল</p>
                  <p className="text-xs text-muted font-mono">.{manuscript.fileType}</p>
                </div>
                <a
                  href={`${process.env.NEXT_PUBLIC_API_URL}${manuscript.fileUrl}`}
                  target="_blank"
                  className="text-gold hover:text-teal"
                >
                  <Download size={16} />
                </a>
              </div>
            ) : (
              <p className="text-muted text-xs mb-3">কোনো ফাইল আপলোড হয়নি।</p>
            )}
            <label className="btn-ghost cursor-pointer w-full justify-center mt-2 text-xs">
              {uploading ? 'আপলোড হচ্ছে...' : <><Upload size={13} /> ফাইল আপলোড</>}
              <input type="file" className="hidden" accept=".pdf,.doc,.docx" onChange={handleUpload} disabled={uploading} />
            </label>
          </div>

          {/* Financial (if exists) */}
          {manuscript.financialRecord && <FinancialCard record={manuscript.financialRecord as any} />}
        </div>

        {/* Stage Timeline */}
        <div className="lg:col-span-2 card p-5">
          <h3 className="font-bold text-ink mb-4 flex items-center gap-2">
            📋 স্টেজ ইতিহাস
          </h3>
          {manuscript.stageLogs && <StageTimeline logs={manuscript.stageLogs} />}
        </div>
      </div>

      {/* Advance Modal */}
      <Modal open={advModal} onClose={() => setAdvModal(false)} title={`স্টেজ পরিবর্তন করুন`}>
        <div className="space-y-4">
          <div className="flex items-center gap-3 bg-paper rounded-lg p-3">
            <StageBadge stage={manuscript.currentStage} />
            <ArrowRight size={16} className="text-muted" />
            {nextStage && <StageBadge stage={nextStage} />}
          </div>
          <div>
            <label className="field-label">মন্তব্য (ঐচ্ছিক)</label>
            <textarea
              className="input h-20 resize-none"
              value={comment}
              onChange={e => setComment(e.target.value)}
              placeholder="স্টেজ পরিবর্তনের কারণ লিখুন..."
            />
          </div>
          <div className="flex gap-3">
            <button onClick={handleAdvance} disabled={advancing} className="btn-gold flex-1 justify-center">
              {advancing ? 'আপডেট হচ্ছে...' : 'স্টেজ পরিবর্তন করুন'}
            </button>
            <button onClick={() => setAdvModal(false)} className="btn-ghost">বাতিল</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

function InfoRow({ label, value }: { label: string; value: any }) {
  return (
    <div className="flex justify-between items-center gap-2">
      <span className="text-muted shrink-0">{label}</span>
      <span className="text-ink font-medium text-right">{value}</span>
    </div>
  )
}
