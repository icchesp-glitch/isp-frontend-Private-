'use client'
import { useState } from 'react'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { useManuscripts } from '@/lib/hooks'
import { post } from '@/lib/api'
import PageHeader from '@/components/shared/PageHeader'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import EmptyState from '@/components/shared/EmptyState'
import Modal from '@/components/shared/Modal'
import { StageBadge } from '@/components/shared/Badge'
import { formatDate } from '@/lib/utils'
import { Plus, Search, LayoutGrid, List, ChevronRight } from 'lucide-react'

export default function ManuscriptsPage() {
  const [search, setSearch] = useState('')
  const [stageFilter, setStageFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const { data, loading, refetch } = useManuscripts({ search: search || undefined, stage: stageFilter || undefined })

  const [form, setForm] = useState({ title: '', authorId: '', genre: '', synopsis: '' })
  const [saving, setSaving] = useState(false)

  const STAGES = ['submitted', 'under_review', 'editing', 'design', 'printing', 'published']
  const STAGE_BN: Record<string, string> = {
    submitted: 'জমা', under_review: 'পর্যালোচনা', editing: 'সম্পাদনা',
    design: 'ডিজাইন', printing: 'মুদ্রণ', published: 'প্রকাশিত',
  }

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const res = await post<any>('/manuscripts', form)
      toast.success('পাণ্ডুলিপি তৈরি হয়েছে!')
      setShowModal(false)
      setForm({ title: '', authorId: '', genre: '', synopsis: '' })
      refetch()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'ত্রুটি হয়েছে')
    } finally { setSaving(false) }
  }

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="পাণ্ডুলিপি"
        subtitle={`মোট ${data?.total ?? 0}টি পাণ্ডুলিপি`}
        actions={
          <div className="flex gap-2">
            <Link href="/admin/manuscripts/pipeline" className="btn-ghost">
              <LayoutGrid size={14} /> পাইপলাইন
            </Link>
            <button onClick={() => setShowModal(true)} className="btn-primary">
              <Plus size={15} /> নতুন পাণ্ডুলিপি
            </button>
          </div>
        }
      />

      {/* Filters */}
      <div className="flex gap-3 mb-6 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={15} />
          <input className="input pl-9" placeholder="শিরোনাম খুঁজুন..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setStageFilter('')}
            className={`text-xs px-3 py-2 rounded-lg border font-semibold transition-all ${!stageFilter ? 'bg-ink text-paper border-ink' : 'bg-white border-border text-muted hover:border-ink'}`}
          >সব</button>
          {STAGES.map(s => (
            <button
              key={s}
              onClick={() => setStageFilter(s === stageFilter ? '' : s)}
              className={`text-xs px-3 py-2 rounded-lg border font-semibold transition-all ${stageFilter === s ? 'bg-ink text-paper border-ink' : 'bg-white border-border text-muted hover:border-ink'}`}
            >{STAGE_BN[s]}</button>
          ))}
        </div>
      </div>

      {loading ? <LoadingSpinner /> : (
        <>
          {!data?.manuscripts?.length ? (
            <EmptyState icon="📚" title="কোনো পাণ্ডুলিপি নেই" action={<button onClick={() => setShowModal(true)} className="btn-primary"><Plus size={15} />পাণ্ডুলিপি যোগ করুন</button>} />
          ) : (
            <div className="card overflow-hidden">
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>শিরোনাম</th>
                      <th>লেখক</th>
                      <th>ঘরানা</th>
                      <th>স্টেজ</th>
                      <th>তারিখ</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.manuscripts.map((m, i) => (
                      <tr key={m.id} className="animate-slide-up" style={{ animationDelay: `${i * 25}ms`, opacity: 0 }}>
                        <td className="font-semibold max-w-[200px]">
                          <span className="line-clamp-1">{m.title}</span>
                        </td>
                        <td>
                          <span className="text-gold font-mono text-xs">{m.author?.authorCode}</span>
                          <span className="text-muted text-xs ml-1">{m.author?.fullName}</span>
                        </td>
                        <td className="text-muted text-xs">{m.genre || '—'}</td>
                        <td><StageBadge stage={m.currentStage} /></td>
                        <td className="text-muted text-xs">{formatDate(m.createdAt)}</td>
                        <td>
                          <Link href={`/admin/manuscripts/${m.id}`} className="text-gold hover:text-teal transition-colors">
                            <ChevronRight size={18} />
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Create Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="নতুন পাণ্ডুলিপি তৈরি করুন">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="field-label">শিরোনাম *</label>
            <input className="input" required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="পাণ্ডুলিপির শিরোনাম" />
          </div>
          <div>
            <label className="field-label">লেখক আইডি *</label>
            <input className="input" required value={form.authorId} onChange={e => setForm({ ...form, authorId: e.target.value })} placeholder="লেখকের UUID" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="field-label">ঘরানা</label>
              <input className="input" value={form.genre} onChange={e => setForm({ ...form, genre: e.target.value })} placeholder="উপন্যাস, গল্প..." />
            </div>
          </div>
          <div>
            <label className="field-label">সারসংক্ষেপ</label>
            <textarea className="input h-20 resize-none" value={form.synopsis} onChange={e => setForm({ ...form, synopsis: e.target.value })} placeholder="সংক্ষিপ্ত বিবরণ..." />
          </div>
          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
              {saving ? 'তৈরি হচ্ছে...' : 'পাণ্ডুলিপি তৈরি করুন'}
            </button>
            <button type="button" onClick={() => setShowModal(false)} className="btn-ghost">বাতিল</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
