'use client'
import { usePipeline } from '@/lib/hooks'
import PageHeader from '@/components/shared/PageHeader'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import ManuscriptKanban from '@/components/admin/ManuscriptKanban'

export default function PipelinePage() {
  const { data: pipeline, loading } = usePipeline()

  return (
    <div className="animate-fade-in">
      <PageHeader title="পাইপলাইন" subtitle="সব পাণ্ডুলিপির স্টেজ-ভিত্তিক দৃশ্য" />
      {loading ? <LoadingSpinner /> : (
        <div className="overflow-x-auto pb-4">
          {pipeline && <ManuscriptKanban pipeline={pipeline} />}
        </div>
      )}
    </div>
  )
}
