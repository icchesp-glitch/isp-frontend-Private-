'use client'
import Link from 'next/link'
import { useAdminDashboard, usePipelineCounts, useAlerts } from '@/lib/hooks'
import KpiCard from '@/components/shared/KpiCard'
import PageHeader from '@/components/shared/PageHeader'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import { StageBadge } from '@/components/shared/Badge'
import { formatCurrency, formatRelative, STAGE_LABELS } from '@/lib/utils'
import { AlertTriangle, ArrowRight } from 'lucide-react'
import type { ManuscriptStage } from '@/types'

export default function DashboardPage() {
  const { data: stats, loading } = useAdminDashboard()
  const { data: pipeline } = usePipelineCounts()
  const { data: alerts } = useAlerts()

  if (loading) return <LoadingSpinner />

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="ড্যাশবোর্ড"
        subtitle="ইচ্ছে স্বপ্ন প্রকাশনী — Publishing OS"
        actions={
          <div className="text-xs font-mono text-muted bg-aged px-3 py-1.5 rounded-full">
            {new Date().toLocaleDateString('bn-BD', { dateStyle: 'long' })}
          </div>
        }
      />

      {/* Alerts */}
      {alerts && alerts.count > 0 && (
        <div className="bg-amber-50 border-2 border-amber-300 rounded-xl p-4 mb-6 flex items-center gap-3">
          <AlertTriangle className="text-amber-600 shrink-0" size={20} />
          <div className="flex-1">
            <p className="text-sm font-bold text-amber-800">
              ⚠️ {alerts.count}টি পাণ্ডুলিপি ১৪ দিনের বেশি একই স্টেজে আটকে আছে
            </p>
            <p className="text-xs text-amber-600 mt-0.5">
              {(alerts.delayed as any[]).slice(0, 2).map((d: any) => d.title).join(', ')}
              {alerts.count > 2 && ` এবং আরও ${alerts.count - 2}টি`}
            </p>
          </div>
          <Link href="/admin/manuscripts?delayed=1" className="text-xs text-amber-700 font-bold hover:underline flex items-center gap-1">
            দেখুন <ArrowRight size={12} />
          </Link>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <KpiCard label="মোট লেখক" value={stats?.authors.total ?? 0} icon="👤" color="default" delay={0} />
        <KpiCard label="পাণ্ডুলিপি" value={stats?.manuscripts.total ?? 0} icon="📚" color="teal" delay={50} />
        <KpiCard label="প্রকাশিত বই" value={stats?.manuscripts.published ?? 0} icon="📗" color="gold" delay={100} />
        <KpiCard
          label="মোট বকেয়া"
          value={formatCurrency(stats?.financials.totalReceivable ?? 0)}
          icon="💰"
          color={stats?.financials.totalReceivable > 0 ? 'rust' : 'default'}
          delay={150}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pipeline Summary */}
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-ink">পাইপলাইন সারসংক্ষেপ</h2>
            <Link href="/admin/manuscripts/pipeline" className="text-xs text-gold font-semibold hover:underline flex items-center gap-1">
              পূর্ণ পাইপলাইন <ArrowRight size={12} />
            </Link>
          </div>
          <div className="space-y-2">
            {pipeline && Object.entries(pipeline).map(([stage, count]) => (
              <div key={stage} className="flex items-center gap-3">
                <div className="w-28 shrink-0">
                  <StageBadge stage={stage as ManuscriptStage} />
                </div>
                <div className="flex-1 bg-aged rounded-full h-2 overflow-hidden">
                  <div
                    className="h-full bg-gold rounded-full transition-all"
                    style={{ width: `${Math.min(100, (count / Math.max(1, stats?.manuscripts.total ?? 1)) * 100)}%` }}
                  />
                </div>
                <span className="text-sm font-mono font-bold text-ink w-6 text-right">{count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="card p-5">
          <h2 className="font-bold text-ink mb-4">সাম্প্রতিক কার্যকলাপ</h2>
          {!stats?.recentActivity?.length ? (
            <p className="text-muted text-sm">কোনো কার্যকলাপ নেই</p>
          ) : (
            <div className="space-y-3">
              {stats.recentActivity.slice(0, 6).map((log: any) => (
                <div key={log.id} className="flex gap-3 items-start">
                  <div className="w-6 h-6 rounded-full bg-aged flex items-center justify-center text-xs shrink-0 mt-0.5">
                    📋
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-ink line-clamp-1">{log.manuscript?.title}</p>
                    <p className="text-xs text-muted">→ {STAGE_LABELS[log.toStage as ManuscriptStage]}</p>
                    <p className="text-xs text-muted/60 font-mono">{formatRelative(log.createdAt)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
