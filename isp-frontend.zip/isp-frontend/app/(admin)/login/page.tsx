'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import { post } from '@/lib/api'
import { setAdminAuth } from '@/lib/auth'
import { Toaster } from 'react-hot-toast'

export default function AdminLogin() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await post<any>('/auth/admin/login', { email, password })
      setAdminAuth(res.access_token, res.user)
      toast.success('স্বাগতম!')
      router.push('/admin/dashboard')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'লগইন ব্যর্থ হয়েছে')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-paper flex items-center justify-center p-4">
      <Toaster position="top-center" />
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold font-display text-ink">ইচ্ছে স্বপ্ন</h1>
          <p className="text-muted text-sm font-mono mt-1 tracking-widest uppercase">প্রকাশনী · Admin</p>
        </div>
        <div className="card p-8">
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="field-label">ইমেইল</label>
              <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="admin@icheshwapno.com" required />
            </div>
            <div>
              <label className="field-label">পাসওয়ার্ড</label>
              <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
              {loading ? 'লগইন হচ্ছে...' : 'লগইন করুন'}
            </button>
          </form>
          <p className="text-center text-xs text-muted mt-5">
            লেখক পোর্টাল?{' '}
            <a href="/portal/login" className="text-gold hover:underline font-semibold">এখানে যান</a>
          </p>
        </div>
      </div>
    </div>
  )
}
