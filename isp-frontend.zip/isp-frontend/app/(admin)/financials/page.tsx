'use client'
import { useState } from 'react'
import toast from 'react-hot-toast'
import { useFinancials, useFinancialOverview } from '@/lib/hooks'
import { post } from '@/lib/api'
import PageHeader from '@/components/shared/PageHeader'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import EmptyState from '@/components/shared/EmptyState'
import Modal from '@/components/shared/Modal'
import KpiCard from '@/components/shared/KpiCard'
import { formatCurrency, formatDate } from '@/lib/utils'
import { Plus, TrendingUp, TrendingDown, Minus } from 'lucide-react'

export default function FinancialsPage() {
  const { data: overview } = useFinancialOverview()
  const { data, loading, refetch } = useFinancials()
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ authorId: '', manuscriptId: '', totalDeal: '', advancePaid: '', deductions: '', notes: '' })
  const [saving, setSaving] = useState(false)

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      await post('/financials', {
        authorId: form.authorId,
        manuscriptId: form.manuscriptId || undefined,
        totalDeal: Number(form.totalDeal) || 0,
        advancePaid: Number(form.advancePaid) || 0,
        deductions: Number(form.deductions) || 0,
        notes: form.notes || undefined,
      })
      toast.success('আর্থিক রেকর্ড তৈরি হয়েছে!')
      setShowModal(false)
      setForm({ authorId: '', manuscriptId: '', totalDeal: '', advancePaid: '', deductions: '', notes: '' })
      refetch()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'ত্রুটি হয়েছে')
    } finally { setSaving(false) }
  }

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="আর্থিক ব্যবস্থাপনা"
        subtitle="চুক্তি, অগ্রিম, কর্তন ও বকেয়া ট্র্যাক করুন"
        actions={
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Plus size={15} /> নতুন রেকর্ড
          </button>
        }
      />

      {/* KPIs */}
      {overview && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <KpiCard label="মোট চুক্তি" value={formatCurrency(overview.totalDeal)} icon="📋" color="default" delay={0} />
          <KpiCard label="মোট অগ্রিম" value={formatCurrency(overview.totalAdvance)} icon="💳" color="teal" delay={50} />
          <KpiCard label="মোট কর্তন" value={formatCurrency(overview.totalDeductions)} icon="✂️" color="default" delay={100} />
          <KpiCard label="মোট বকেয়া" value={formatCurrency(overview.totalDue)} icon="⚖️" color={overview.totalDue > 0 ? 'rust' : 'teal'} delay={150} />
        </div>
      )}

      {loading ? <LoadingSpinner /> : (
        <>
          {!data?.records?.length ? (
            <EmptyState icon="💰" title="কোনো আর্থিক রেকর্ড নেই"
              action={<button onClick={() => setShowModal(true)} className="btn-primary"><Plus size={15} />রেকর্ড তৈরি করুন</button>}
            />
          ) : (
            <div className="card overflow-hidden">
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>লেখক</th>
                      <th>পাণ্ডুলিপি</th>
                      <th>চুক্তি</th>
                      <th>অগ্রিম</th>
                      <th>কর্তন</th>
                      <th>বকেয়া</th>
                      <th>তারিখ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.records.map((r, i) => {
                      const balance = Number(r.balanceDue)
                      return (
                        <tr key={r.id} className="animate-slide-up" style={{ animationDelay: `${i * 25}ms`, opacity: 0 }}>
                          <td>
                            <p className="font-bold text-xs">{r.author?.fullName}</p>
                            <p className="text-gold font-mono text-xs">{r.author?.authorCode}</p>
                          </td>
                          <td className="text-xs text-muted max-w-[140px]">
                            <span className="line-clamp-1">{r.manuscript?.title || '—'}</span>
                          </td>
                          <td className="font-mono text-sm">{formatCurrency(r.totalDeal)}</td>
                          <td className="font-mono text-sm text-teal">{formatCurrency(r.advancePaid)}</td>
                          <td className="font-mono text-sm text-rust">{formatCurrency(r.deductions)}</td>
                          <td>
                            <span className={`font-mono text-sm font-bold flex items-center gap-1 ${
                              balance > 0 ? 'text-rust' : balance < 0 ? 'text-teal' : 'text-muted'
                            }`}>
                              {balance > 0 ? <TrendingUp size={13} /> : balance < 0 ? <TrendingDown size={13} /> : <Minus size={13} />}
                              {formatCurrency(Math.abs(balance))}
                            </span>
                          </td>
                          <td className="text-muted text-xs">{formatDate(r.createdAt)}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Create Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="নতুন আর্থিক রেকর্ড" width="max-w-xl">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="field-label">লেখক আইডি *</label>
              <input className="input" required value={form.authorId} onChange={e => setForm({ ...form, authorId: e.target.value })} placeholder="লেখকের UUID" />
            </div>
            <div className="col-span-2">
              <label className="field-label">পাণ্ডুলিপি আইডি (ঐচ্ছিক)</label>
              <input className="input" value={form.manuscriptId} onChange={e => setForm({ ...form, manuscriptId: e.target.value })} placeholder="পাণ্ডুলিপির UUID" />
            </div>
            <div>
              <label className="field-label">মোট চুক্তি (৳)</label>
              <input className="input" type="number" min="0" value={form.totalDeal} onChange={e => setForm({ ...form, totalDeal: e.target.value })} placeholder="0" />
            </div>
            <div>
              <label className="field-label">অগ্রিম পরিশোধ (৳)</label>
              <input className="input" type="number" min="0" value={form.advancePaid} onChange={e => setForm({ ...form, advancePaid: e.target.value })} placeholder="0" />
            </div>
            <div>
              <label className="field-label">কর্তন (৳)</label>
              <input className="input" type="number" min="0" value={form.deductions} onChange={e => setForm({ ...form, deductions: e.target.value })} placeholder="0" />
            </div>
            <div className="flex items-end">
              <div className="bg-paper border border-border rounded-lg p-3 w-full text-sm">
                <p className="text-muted text-xs">বকেয়া (হিসাব)</p>
                <p className="font-mono font-bold text-rust mt-0.5">
                  {formatCurrency(
                    (Number(form.totalDeal) || 0) - (Number(form.advancePaid) || 0) - (Number(form.deductions) || 0)
                  )}
                </p>
              </div>
            </div>
            <div className="col-span-2">
              <label className="field-label">নোট</label>
              <input className="input" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="চুক্তির বিবরণ..." />
            </div>
          </div>
          <div className="flex gap-3 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
              {saving ? 'তৈরি হচ্ছে...' : 'রেকর্ড তৈরি করুন'}
            </button>
            <button type="button" onClick={() => setShowModal(false)} className="btn-ghost">বাতিল</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
