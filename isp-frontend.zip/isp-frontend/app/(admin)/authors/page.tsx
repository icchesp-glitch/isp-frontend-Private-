'use client'
import { useState } from 'react'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { useAuthors } from '@/lib/hooks'
import { post } from '@/lib/api'
import PageHeader from '@/components/shared/PageHeader'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import EmptyState from '@/components/shared/EmptyState'
import Modal from '@/components/shared/Modal'
import { AuthorBadge } from '@/components/shared/Badge'
import { formatDate } from '@/lib/utils'
import { Plus, Search, ChevronRight } from 'lucide-react'

export default function AuthorsPage() {
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const { data, loading, refetch } = useAuthors({ search: search || undefined })

  const [form, setForm] = useState({ fullName: '', email: '', phone: '', address: '', nid: '' })
  const [saving, setSaving] = useState(false)

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      await post('/authors', form)
      toast.success('লেখক তৈরি হয়েছে!')
      setShowModal(false)
      setForm({ fullName: '', email: '', phone: '', address: '', nid: '' })
      refetch()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'ত্রুটি হয়েছে')
    } finally { setSaving(false) }
  }

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="লেখকবৃন্দ"
        subtitle={`মোট ${data?.total ?? 0} জন লেখক`}
        actions={
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Plus size={15} /> নতুন লেখক
          </button>
        }
      />

      {/* Search */}
      <div className="relative mb-6 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={15} />
        <input
          className="input pl-9"
          placeholder="নাম, কোড বা ইমেইল খুঁজুন..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {loading ? <LoadingSpinner /> : (
        <>
          {!data?.authors?.length ? (
            <EmptyState icon="👤" title="কোনো লেখক নেই" subtitle="নতুন লেখক যোগ করুন" action={<button onClick={() => setShowModal(true)} className="btn-primary"><Plus size={15} /> লেখক যোগ করুন</button>} />
          ) : (
            <div className="card overflow-hidden">
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>কোড</th>
                      <th>নাম</th>
                      <th>ইমেইল</th>
                      <th>ব্যাজ</th>
                      <th>পাণ্ডুলিপি</th>
                      <th>যোগদান</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.authors.map((author, i) => (
                      <tr key={author.id} className="animate-slide-up" style={{ animationDelay: `${i * 30}ms`, opacity: 0 }}>
                        <td><span className="font-mono text-xs font-bold text-gold">{author.authorCode}</span></td>
                        <td className="font-semibold">{author.fullName}</td>
                        <td className="text-muted">{author.email}</td>
                        <td><AuthorBadge status={author.badgeStatus} /></td>
                        <td className="text-center font-mono">{author._count?.manuscripts ?? 0}</td>
                        <td className="text-muted text-xs">{formatDate(author.createdAt)}</td>
                        <td>
                          <Link href={`/admin/authors/${author.id}`} className="text-gold hover:text-teal transition-colors">
                            <ChevronRight size={18} />
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Create Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="নতুন লেখক তৈরি করুন">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="field-label">পুরো নাম *</label>
              <input className="input" required value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} placeholder="আরিফ হোসেন" />
            </div>
            <div className="col-span-2">
              <label className="field-label">ইমেইল *</label>
              <input className="input" type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="arif@email.com" />
            </div>
            <div>
              <label className="field-label">ফোন</label>
              <input className="input" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="01700000000" />
            </div>
            <div>
              <label className="field-label">NID</label>
              <input className="input" value={form.nid} onChange={e => setForm({ ...form, nid: e.target.value })} placeholder="জাতীয় পরিচয়পত্র নম্বর" />
            </div>
            <div className="col-span-2">
              <label className="field-label">ঠিকানা</label>
              <input className="input" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="বাসার ঠিকানা" />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
              {saving ? 'তৈরি হচ্ছে...' : 'লেখক তৈরি করুন'}
            </button>
            <button type="button" onClick={() => setShowModal(false)} className="btn-ghost">বাতিল</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
