'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import toast from 'react-hot-toast'
import { useAuthor } from '@/lib/hooks'
import { patch, post } from '@/lib/api'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import PageHeader from '@/components/shared/PageHeader'
import Modal from '@/components/shared/Modal'
import { AuthorBadge, StageBadge, PaymentBadge } from '@/components/shared/Badge'
import { formatDate, formatCurrency } from '@/lib/utils'
import { Edit, Key, Award, BookOpen, FileText, ChevronRight } from 'lucide-react'

export default function AuthorDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { data: author, loading, refetch } = useAuthor(id)

  const [badgeModal, setBadgeModal] = useState(false)
  const [portalModal, setPortalModal] = useState(false)
  const [badgeStatus, setBadgeStatus] = useState('')
  const [portalPw, setPortalPw] = useState('')
  const [saving, setSaving] = useState(false)

  const handleBadge = async () => {
    setSaving(true)
    try {
      await patch(`/authors/${id}/badge`, { badgeStatus })
      toast.success('ব্যাজ আপডেট হয়েছে')
      setBadgeModal(false)
      refetch()
    } catch { toast.error('ত্রুটি হয়েছে') }
    finally { setSaving(false) }
  }

  const handlePortal = async () => {
    setSaving(true)
    try {
      await post(`/authors/${id}/portal-access`, { password: portalPw })
      toast.success('পোর্টাল অ্যাক্সেস দেওয়া হয়েছে')
      setPortalModal(false)
      setPortalPw('')
      refetch()
    } catch { toast.error('ত্রুটি হয়েছে') }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSpinner />
  if (!author) return <p className="text-muted">লেখক পাওয়া যায়নি।</p>

  return (
    <div className="animate-fade-in">
      <PageHeader
        title={author.fullName}
        subtitle={`${author.authorCode} · ${author.email}`}
        actions={
          <div className="flex gap-2">
            <button onClick={() => { setBadgeStatus(author.badgeStatus); setBadgeModal(true) }} className="btn-ghost">
              <Award size={14} /> ব্যাজ
            </button>
            <button onClick={() => setPortalModal(true)} className="btn-ghost">
              <Key size={14} /> পোর্টাল
            </button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <div className="card p-6">
          <div className="flex flex-col items-center text-center mb-4">
            <div className="w-16 h-16 rounded-full bg-ink flex items-center justify-center text-gold text-2xl font-bold font-display mb-3">
              {author.fullName[0]}
            </div>
            <h2 className="font-bold text-ink text-lg">{author.fullName}</h2>
            <span className="font-mono text-xs text-gold mt-1">{author.authorCode}</span>
            <div className="mt-2"><AuthorBadge status={author.badgeStatus} /></div>
          </div>
          <div className="space-y-2 text-sm border-t border-border pt-4">
            <InfoRow label="ইমেইল" value={author.email} />
            {author.phone && <InfoRow label="ফোন" value={author.phone} />}
            {author.address && <InfoRow label="ঠিকানা" value={author.address} />}
            <InfoRow label="পোর্টাল" value={author.portalAccess ? '✅ সক্রিয়' : '❌ নিষ্ক্রিয়'} />
            <InfoRow label="যোগদান" value={formatDate(author.createdAt)} />
          </div>
        </div>

        {/* Manuscripts */}
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-ink flex items-center gap-2"><BookOpen size={16} /> পাণ্ডুলিপিসমূহ ({author._count?.manuscripts ?? 0})</h3>
            <Link href={`/admin/manuscripts/new?authorId=${id}`} className="text-xs text-gold font-semibold hover:underline">+ নতুন</Link>
          </div>
          {!author.manuscripts?.length ? (
            <p className="text-muted text-sm text-center py-8">কোনো পাণ্ডুলিপি নেই।</p>
          ) : (
            <div className="space-y-2">
              {author.manuscripts.map((m) => (
                <Link key={m.id} href={`/admin/manuscripts/${m.id}`}>
                  <div className="flex items-center justify-between p-3 rounded-lg hover:bg-paper border border-transparent hover:border-border transition-all cursor-pointer">
                    <div>
                      <p className="font-semibold text-sm text-ink">{m.title}</p>
                      <p className="text-xs text-muted mt-0.5">{m.genre} · {formatDate(m.createdAt)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <StageBadge stage={m.currentStage} />
                      <ChevronRight size={14} className="text-muted" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Badge Modal */}
      <Modal open={badgeModal} onClose={() => setBadgeModal(false)} title="ব্যাজ আপডেট করুন">
        <div className="space-y-4">
          <div>
            <label className="field-label">নতুন ব্যাজ স্ট্যাটাস</label>
            <select className="input" value={badgeStatus} onChange={e => setBadgeStatus(e.target.value)}>
              <option value="unverified">অযাচাইকৃত</option>
              <option value="active">সক্রিয়</option>
              <option value="verified">যাচাইকৃত ⭐</option>
            </select>
          </div>
          <div className="flex gap-3">
            <button onClick={handleBadge} disabled={saving} className="btn-primary flex-1 justify-center">
              {saving ? 'সংরক্ষণ...' : 'আপডেট করুন'}
            </button>
            <button onClick={() => setBadgeModal(false)} className="btn-ghost">বাতিল</button>
          </div>
        </div>
      </Modal>

      {/* Portal Modal */}
      <Modal open={portalModal} onClose={() => setPortalModal(false)} title="পোর্টাল অ্যাক্সেস দিন">
        <div className="space-y-4">
          <p className="text-sm text-muted">এই লেখককে লেখক পোর্টালে লগইন করার অনুমতি দিন।</p>
          <div>
            <label className="field-label">পোর্টাল পাসওয়ার্ড</label>
            <input className="input" type="password" value={portalPw} onChange={e => setPortalPw(e.target.value)} placeholder="কমপক্ষে ৬ অক্ষর" />
          </div>
          <div className="flex gap-3">
            <button onClick={handlePortal} disabled={saving || !portalPw} className="btn-primary flex-1 justify-center">
              {saving ? 'সংরক্ষণ...' : 'অ্যাক্সেস দিন'}
            </button>
            <button onClick={() => setPortalModal(false)} className="btn-ghost">বাতিল</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-muted">{label}</span>
      <span className="text-ink font-medium text-right">{value}</span>
    </div>
  )
}
