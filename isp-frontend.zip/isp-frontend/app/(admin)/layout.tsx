'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { isLoggedIn, getRole } from '@/lib/auth'
import Sidebar from '@/components/shared/Sidebar'
import { Toaster } from 'react-hot-toast'

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()

  useEffect(() => {
    if (!isLoggedIn() || getRole() !== 'admin') {
      router.push('/admin/login')
    }
  }, [router])

  return (
    <div className="flex min-h-screen bg-paper">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
      <Toaster position="top-right" toastOptions={{ style: { fontFamily: 'Hind Siliguri', fontSize: '14px' } }} />
    </div>
  )
}
