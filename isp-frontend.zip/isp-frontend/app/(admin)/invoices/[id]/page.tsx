'use client'
import { useState } from 'react'
import { useParams } from 'next/navigation'
import toast from 'react-hot-toast'
import { useInvoice } from '@/lib/hooks'
import { patch } from '@/lib/api'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import PageHeader from '@/components/shared/PageHeader'
import { PaymentBadge } from '@/components/shared/Badge'
import { formatDate, formatCurrency } from '@/lib/utils'
import { Download, CheckCircle } from 'lucide-react'

export default function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { data: inv, loading, refetch } = useInvoice(id)
  const [status, setStatus] = useState('')
  const [amountPaid, setAmountPaid] = useState('')
  const [saving, setSaving] = useState(false)

  const handleUpdate = async () => {
    setSaving(true)
    try {
      await patch(`/invoices/${id}/payment`, {
        paymentStatus: status || inv?.paymentStatus,
        amountPaid: amountPaid ? Number(amountPaid) : undefined,
      })
      toast.success('আপডেট হয়েছে!')
      refetch()
    } catch { toast.error('ত্রুটি হয়েছে') }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSpinner />
  if (!inv) return <p className="text-muted">ইনভয়েস পাওয়া যায়নি।</p>

  const balance = Number(inv.amount) - Number(inv.amountPaid)

  return (
    <div className="animate-fade-in max-w-2xl">
      <PageHeader
        title={inv.invoiceNumber}
        subtitle={`${inv.author?.fullName} · ${inv.author?.authorCode}`}
        actions={
          <a
            href={`${process.env.NEXT_PUBLIC_API_URL}/api/invoices/${id}/pdf`}
            target="_blank"
            className="btn-ghost"
          >
            <Download size={14} /> PDF ডাউনলোড
          </a>
        }
      />

      <div className="grid gap-5">
        {/* Invoice Summary */}
        <div className="card p-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <p className="text-xs font-mono text-muted uppercase tracking-widest">ইচ্ছে স্বপ্ন প্রকাশনী</p>
              <h2 className="text-2xl font-bold font-display text-gold mt-1">{inv.invoiceNumber}</h2>
            </div>
            <PaymentBadge status={inv.paymentStatus} />
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
            <div>
              <p className="text-muted text-xs mb-1">লেখক</p>
              <p className="font-bold">{inv.author?.fullName}</p>
              <p className="text-muted text-xs">{inv.author?.email}</p>
            </div>
            <div className="text-right">
              <p className="text-muted text-xs mb-1">তারিখ</p>
              <p className="font-semibold">{formatDate(inv.createdAt)}</p>
              {inv.dueDate && (
                <>
                  <p className="text-muted text-xs mt-2 mb-1">শেষ তারিখ</p>
                  <p className="font-semibold text-rust">{formatDate(inv.dueDate)}</p>
                </>
              )}
            </div>
          </div>

          {inv.manuscript && (
            <div className="bg-paper rounded-lg p-3 mb-4 text-sm">
              <span className="text-muted">পাণ্ডুলিপি:</span>
              <span className="font-semibold ml-2">{inv.manuscript.title}</span>
            </div>
          )}

          {inv.notes && (
            <p className="text-muted text-xs bg-aged rounded-lg p-3 mb-4">{inv.notes}</p>
          )}

          {/* Amounts */}
          <div className="border-t border-border pt-4 space-y-2">
            <Row label="মোট পরিমাণ" value={formatCurrency(inv.amount)} bold />
            <Row label="পরিশোধিত" value={formatCurrency(inv.amountPaid)} color="text-teal" />
            <div className="border-t border-border pt-2">
              <Row
                label="বকেয়া"
                value={formatCurrency(balance)}
                color={balance > 0 ? 'text-rust font-bold' : 'text-teal font-bold'}
                bold
              />
            </div>
          </div>
        </div>

        {/* Update Payment */}
        <div className="card p-5">
          <h3 className="font-bold text-ink mb-4 flex items-center gap-2">
            <CheckCircle size={16} className="text-teal" /> পেমেন্ট আপডেট
          </h3>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div>
              <label className="field-label">স্ট্যাটাস</label>
              <select
                className="input"
                value={status || inv.paymentStatus}
                onChange={e => setStatus(e.target.value)}
              >
                <option value="pending">বকেয়া</option>
                <option value="partial">আংশিক</option>
                <option value="paid">পরিশোধিত</option>
              </select>
            </div>
            <div>
              <label className="field-label">পরিশোধিত পরিমাণ</label>
              <input
                className="input"
                type="number"
                min="0"
                value={amountPaid || inv.amountPaid}
                onChange={e => setAmountPaid(e.target.value)}
                placeholder="০"
              />
            </div>
          </div>
          <button onClick={handleUpdate} disabled={saving} className="btn-primary w-full justify-center">
            {saving ? 'আপডেট হচ্ছে...' : 'পেমেন্ট আপডেট করুন'}
          </button>
        </div>
      </div>
    </div>
  )
}

function Row({ label, value, bold, color }: { label: string; value: string; bold?: boolean; color?: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-muted">{label}</span>
      <span className={`font-mono ${bold ? 'font-bold' : ''} ${color || 'text-ink'}`}>{value}</span>
    </div>
  )
}
