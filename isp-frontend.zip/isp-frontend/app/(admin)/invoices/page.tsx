'use client'
import { useState } from 'react'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { useInvoices } from '@/lib/hooks'
import { post } from '@/lib/api'
import PageHeader from '@/components/shared/PageHeader'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import EmptyState from '@/components/shared/EmptyState'
import Modal from '@/components/shared/Modal'
import { PaymentBadge } from '@/components/shared/Badge'
import { formatDate, formatCurrency } from '@/lib/utils'
import { Plus, ChevronRight, Download } from 'lucide-react'

export default function InvoicesPage() {
  const [statusFilter, setStatusFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const { data, loading, refetch } = useInvoices({ status: statusFilter || undefined })

  const [form, setForm] = useState({ authorId: '', manuscriptId: '', amount: '', dueDate: '', notes: '' })
  const [saving, setSaving] = useState(false)

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      await post('/invoices', { ...form, amount: Number(form.amount) })
      toast.success('ইনভয়েস তৈরি হয়েছে!')
      setShowModal(false)
      setForm({ authorId: '', manuscriptId: '', amount: '', dueDate: '', notes: '' })
      refetch()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'ত্রুটি হয়েছে')
    } finally { setSaving(false) }
  }

  const STATUSES = [
    { val: '', label: 'সব' },
    { val: 'pending', label: 'বকেয়া' },
    { val: 'partial', label: 'আংশিক' },
    { val: 'paid', label: 'পরিশোধিত' },
  ]

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="ইনভয়েস"
        subtitle={`মোট ${data?.total ?? 0}টি ইনভয়েস`}
        actions={
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Plus size={15} /> নতুন ইনভয়েস
          </button>
        }
      />

      {/* Status Filters */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {STATUSES.map(s => (
          <button
            key={s.val}
            onClick={() => setStatusFilter(s.val)}
            className={`text-xs px-4 py-2 rounded-lg border font-semibold transition-all ${
              statusFilter === s.val ? 'bg-ink text-paper border-ink' : 'bg-white border-border text-muted hover:border-ink'
            }`}
          >{s.label}</button>
        ))}
      </div>

      {loading ? <LoadingSpinner /> : (
        <>
          {!data?.invoices?.length ? (
            <EmptyState icon="🧾" title="কোনো ইনভয়েস নেই"
              action={<button onClick={() => setShowModal(true)} className="btn-primary"><Plus size={15} />ইনভয়েস তৈরি করুন</button>}
            />
          ) : (
            <div className="card overflow-hidden">
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>ইনভয়েস নম্বর</th>
                      <th>লেখক</th>
                      <th>পাণ্ডুলিপি</th>
                      <th>পরিমাণ</th>
                      <th>পরিশোধ</th>
                      <th>স্ট্যাটাস</th>
                      <th>তারিখ</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.invoices.map((inv, i) => (
                      <tr key={inv.id} className="animate-slide-up" style={{ animationDelay: `${i * 25}ms`, opacity: 0 }}>
                        <td>
                          <span className="font-mono text-xs font-bold text-gold">{inv.invoiceNumber}</span>
                        </td>
                        <td>
                          <p className="text-xs font-bold">{inv.author?.fullName}</p>
                          <p className="text-xs text-muted font-mono">{inv.author?.authorCode}</p>
                        </td>
                        <td className="text-xs text-muted max-w-[140px]">
                          <span className="line-clamp-1">{inv.manuscript?.title || '—'}</span>
                        </td>
                        <td className="font-mono font-bold text-sm">{formatCurrency(inv.amount)}</td>
                        <td className="font-mono text-sm text-teal">{formatCurrency(inv.amountPaid)}</td>
                        <td><PaymentBadge status={inv.paymentStatus} /></td>
                        <td className="text-muted text-xs">{formatDate(inv.createdAt)}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            {inv.pdfUrl && (
                              <a
                                href={`${process.env.NEXT_PUBLIC_API_URL}/api/invoices/${inv.id}/pdf`}
                                target="_blank"
                                className="text-muted hover:text-gold transition-colors"
                                title="PDF ডাউনলোড"
                              >
                                <Download size={15} />
                              </a>
                            )}
                            <Link href={`/admin/invoices/${inv.id}`} className="text-gold hover:text-teal transition-colors">
                              <ChevronRight size={18} />
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Create Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="নতুন ইনভয়েস তৈরি করুন">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="field-label">লেখক আইডি *</label>
            <input className="input" required value={form.authorId} onChange={e => setForm({ ...form, authorId: e.target.value })} placeholder="লেখকের UUID" />
          </div>
          <div>
            <label className="field-label">পাণ্ডুলিপি আইডি (ঐচ্ছিক)</label>
            <input className="input" value={form.manuscriptId} onChange={e => setForm({ ...form, manuscriptId: e.target.value })} placeholder="পাণ্ডুলিপির UUID" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="field-label">পরিমাণ (টাকা) *</label>
              <input className="input" type="number" required min="0" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} placeholder="10000" />
            </div>
            <div>
              <label className="field-label">শেষ তারিখ</label>
              <input className="input" type="date" value={form.dueDate} onChange={e => setForm({ ...form, dueDate: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="field-label">নোট</label>
            <input className="input" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="প্রকাশনা সেবা..." />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
              {saving ? 'তৈরি হচ্ছে...' : 'ইনভয়েস তৈরি করুন'}
            </button>
            <button type="button" onClick={() => setShowModal(false)} className="btn-ghost">বাতিল</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
