'use client'
import { useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { isLoggedIn, getRole, getUser, logout } from '@/lib/auth'
import { Toaster } from 'react-hot-toast'
import { BookOpen, DollarSign, FileText, LayoutDashboard, LogOut } from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/portal/dashboard',             label: 'ড্যাশবোর্ড', icon: LayoutDashboard },
  { href: '/portal/dashboard/manuscripts', label: 'পাণ্ডুলিপি',  icon: BookOpen },
  { href: '/portal/dashboard/financials',  label: 'আর্থিক',      icon: DollarSign },
  { href: '/portal/dashboard/invoices',    label: 'ইনভয়েস',      icon: FileText },
]

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const path = usePathname()

  useEffect(() => {
    if (path === '/portal/login') return
    if (!isLoggedIn() || getRole() !== 'author') router.push('/portal/login')
  }, [router, path])

  if (path === '/portal/login') {
    return (
      <>
        {children}
        <Toaster position="top-center" toastOptions={{ style: { fontFamily: 'Hind Siliguri' } }} />
      </>
    )
  }

  const user = getUser()

  return (
    <div className="min-h-screen bg-paper">
      {/* Top Navbar */}
      <header className="bg-ink border-b-2 border-gold sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-6 h-14 flex items-center justify-between">
          <div>
            <span className="text-gold font-display font-bold text-lg">ইচ্ছে স্বপ্ন</span>
            <span className="text-white/30 text-xs font-mono ml-2">লেখক পোর্টাল</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-white/60 text-sm hidden sm:block">{user?.fullName}</span>
            <button
              onClick={() => { logout(); router.push('/portal/login') }}
              className="text-white/40 hover:text-white transition-colors"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-6 py-8">
        {/* Tab Nav */}
        <nav className="flex gap-1 mb-8 bg-aged/50 rounded-xl p-1.5 w-fit">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = path === href
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all',
                  active ? 'bg-white shadow text-ink' : 'text-muted hover:text-ink'
                )}
              >
                <Icon size={15} />
                <span className="hidden sm:inline">{label}</span>
              </Link>
            )
          })}
        </nav>

        {children}
      </div>

      <Toaster position="top-right" toastOptions={{ style: { fontFamily: 'Hind Siliguri' } }} />
    </div>
  )
}
