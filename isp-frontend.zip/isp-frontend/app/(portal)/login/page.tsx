'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import { post } from '@/lib/api'
import { setAuthorAuth } from '@/lib/auth'

export default function PortalLogin() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await post<any>('/auth/author/login', { email, password })
      setAuthorAuth(res.access_token, res.author)
      toast.success(`স্বাগতম, ${res.author.fullName}!`)
      router.push('/portal/dashboard')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'লগইন ব্যর্থ হয়েছে')
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-paper flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">✍️</div>
          <h1 className="text-3xl font-bold font-display text-ink">লেখক পোর্টাল</h1>
          <p className="text-muted text-sm mt-1">ইচ্ছে স্বপ্ন প্রকাশনী</p>
        </div>
        <div className="card p-8">
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="field-label">ইমেইল</label>
              <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="আপনার ইমেইল" required />
            </div>
            <div>
              <label className="field-label">পাসওয়ার্ড</label>
              <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            <button type="submit" disabled={loading} className="btn-gold w-full justify-center py-3">
              {loading ? 'লগইন হচ্ছে...' : 'লগইন করুন'}
            </button>
          </form>
          <p className="text-center text-xs text-muted mt-5">
            অ্যাডমিন?{' '}
            <a href="/admin/login" className="text-teal hover:underline font-semibold">অ্যাডমিন পোর্টালে যান</a>
          </p>
        </div>
        <p className="text-center text-xs text-muted mt-4">
          পোর্টাল অ্যাক্সেসের জন্য প্রকাশকের সাথে যোগাযোগ করুন।
        </p>
      </div>
    </div>
  )
}
