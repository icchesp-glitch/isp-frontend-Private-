'use client'
import { useAuthorDashboard } from '@/lib/hooks'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import { PaymentBadge } from '@/components/shared/Badge'
import { formatDate, formatCurrency } from '@/lib/utils'
import { Download } from 'lucide-react'

export default function PortalInvoices() {
  const { data, loading } = useAuthorDashboard()

  if (loading) return <LoadingSpinner />
  const invoices = data?.invoices || []

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold font-display text-ink mb-6">ইনভয়েস</h1>

      {!invoices.length ? (
        <div className="card p-12 text-center">
          <p className="text-4xl mb-3">🧾</p>
          <p className="font-semibold text-ink">কোনো ইনভয়েস নেই।</p>
        </div>
      ) : (
        <div className="space-y-3">
          {invoices.map((inv: any, i: number) => (
            <div key={inv.invoiceNumber} className="card p-5 animate-slide-up flex items-center justify-between gap-4"
              style={{ animationDelay: `${i * 40}ms`, opacity: 0 }}>
              <div>
                <p className="font-mono font-bold text-gold">{inv.invoiceNumber}</p>
                <p className="text-xs text-muted mt-1">{formatDate(inv.createdAt)}</p>
                {inv.dueDate && (
                  <p className="text-xs text-rust mt-0.5">শেষ তারিখ: {formatDate(inv.dueDate)}</p>
                )}
              </div>
              <div className="text-right flex-1">
                <p className="font-mono font-bold text-lg text-ink">{formatCurrency(inv.amount)}</p>
                {Number(inv.amountPaid) > 0 && (
                  <p className="text-xs text-teal font-mono">পরিশোধিত: {formatCurrency(inv.amountPaid)}</p>
                )}
                <div className="mt-1"><PaymentBadge status={inv.paymentStatus} /></div>
              </div>
              {inv.pdfUrl && (
                <a
                  href={`${process.env.NEXT_PUBLIC_API_URL}/api/invoices/${inv.invoiceNumber}/pdf`}
                  className="btn-ghost shrink-0 text-xs"
                  target="_blank"
                >
                  <Download size={14} /> PDF
                </a>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
