'use client'
import { useAuthorDashboard } from '@/lib/hooks'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import { formatCurrency } from '@/lib/utils'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

export default function PortalFinancials() {
  const { data, loading } = useAuthorDashboard()

  if (loading) return <LoadingSpinner />
  const fin = data?.financials

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold font-display text-ink mb-6">আর্থিক বিবরণ</h1>

      {!fin ? (
        <div className="card p-12 text-center">
          <p className="text-4xl mb-3">💰</p>
          <p className="font-semibold text-ink">কোনো আর্থিক রেকর্ড নেই।</p>
        </div>
      ) : (
        <div className="space-y-5 max-w-lg">
          <div className="card p-6">
            <h2 className="text-xs font-mono uppercase tracking-widest text-muted mb-5">চুক্তি সারসংক্ষেপ</h2>
            <div className="space-y-4">
              <BigRow label="মোট চুক্তি মূল্য" value={formatCurrency(fin.totalDeal)} icon="📋" />
              <BigRow label="অগ্রিম পরিশোধিত" value={formatCurrency(fin.advancePaid)} icon="✅" color="text-teal" />
              <BigRow label="কর্তন (সম্পাদনা/ডিজাইন)" value={formatCurrency(fin.deductions)} icon="✂️" color="text-rust" />
            </div>

            <div className="border-t-2 border-border mt-5 pt-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted text-sm">বকেয়া ব্যালেন্স</p>
                  <p className="text-xs text-muted mt-0.5">
                    {fin.balanceDue > 0 ? '(প্রকাশক আপনাকে দেবেন)' :
                     fin.balanceDue < 0 ? '(আপনি প্রকাশককে দেবেন)' : '(নিষ্পত্তি হয়ে গেছে)'}
                  </p>
                </div>
                <div className={`flex items-center gap-2 text-2xl font-bold font-display ${
                  fin.balanceDue > 0 ? 'text-teal' :
                  fin.balanceDue < 0 ? 'text-rust' : 'text-muted'
                }`}>
                  {fin.balanceDue > 0 ? <TrendingUp size={22} /> :
                   fin.balanceDue < 0 ? <TrendingDown size={22} /> : <Minus size={22} />}
                  {formatCurrency(Math.abs(fin.balanceDue))}
                </div>
              </div>
            </div>

            {fin.notes && (
              <p className="text-xs text-muted bg-paper rounded-lg p-3 mt-4 border border-border">
                📝 {fin.notes}
              </p>
            )}
          </div>

          <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4">
            <p className="text-xs text-amber-700 font-semibold">
              ℹ️ এই তথ্য আপনার প্রকাশকের রেকর্ড অনুযায়ী। কোনো প্রশ্ন থাকলে সরাসরি যোগাযোগ করুন।
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

function BigRow({ label, value, icon, color }: { label: string; value: string; icon: string; color?: string }) {
  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-3">
        <span className="text-xl">{icon}</span>
        <span className="text-sm text-muted">{label}</span>
      </div>
      <span className={`font-mono font-bold text-lg ${color || 'text-ink'}`}>{value}</span>
    </div>
  )
}
