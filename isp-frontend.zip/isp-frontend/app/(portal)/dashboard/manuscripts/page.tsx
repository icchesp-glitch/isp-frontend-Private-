'use client'
import { useAuthorDashboard } from '@/lib/hooks'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import StageTimeline from '@/components/admin/StageTimeline'
import { StageBadge } from '@/components/shared/Badge'
import { formatDate } from '@/lib/utils'
import { STAGE_LABELS, STAGE_ORDER } from '@/lib/utils'
import { useState } from 'react'
import { ChevronDown, ChevronUp } from 'lucide-react'
import type { ManuscriptStage } from '@/types'

export default function PortalManuscripts() {
  const { data, loading } = useAuthorDashboard()
  const [expanded, setExpanded] = useState<string | null>(null)

  if (loading) return <LoadingSpinner />

  const manuscripts = data?.manuscripts || []

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold font-display text-ink mb-6">আমার পাণ্ডুলিপি</h1>

      {!manuscripts.length ? (
        <div className="card p-12 text-center">
          <p className="text-4xl mb-3">📚</p>
          <p className="font-semibold text-ink">কোনো পাণ্ডুলিপি নেই।</p>
          <p className="text-muted text-sm mt-1">প্রকাশকের সাথে যোগাযোগ করুন।</p>
        </div>
      ) : (
        <div className="space-y-4">
          {manuscripts.map((m: any, i: number) => {
            const isOpen = expanded === m.id
            const currentIdx = STAGE_ORDER.indexOf(m.currentStage)
            return (
              <div key={m.id} className="card overflow-hidden animate-slide-up" style={{ animationDelay: `${i * 50}ms`, opacity: 0 }}>
                {/* Header */}
                <div
                  className="p-5 cursor-pointer hover:bg-paper/50 transition-colors"
                  onClick={() => setExpanded(isOpen ? null : m.id)}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h2 className="font-bold text-ink text-lg leading-tight">{m.title}</h2>
                      <div className="flex items-center gap-3 mt-2 flex-wrap">
                        {m.genre && <span className="text-xs text-muted bg-aged px-2 py-0.5 rounded">{m.genre}</span>}
                        <span className="text-xs text-muted">{formatDate(m.createdAt)}</span>
                        {m.isPublished && <span className="text-xs font-bold text-teal">📗 প্রকাশিত</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <StageBadge stage={m.currentStage} />
                      {isOpen ? <ChevronUp size={16} className="text-muted" /> : <ChevronDown size={16} className="text-muted" />}
                    </div>
                  </div>

                  {/* Mini progress */}
                  <div className="flex items-center gap-1 mt-4 overflow-x-auto pb-1">
                    {STAGE_ORDER.map((s, idx) => (
                      <div
                        key={s}
                        className={`h-1.5 flex-1 rounded-full transition-all ${
                          idx < currentIdx ? 'bg-teal' :
                          idx === currentIdx ? 'bg-gold' : 'bg-aged'
                        }`}
                      />
                    ))}
                  </div>
                  <div className="flex justify-between text-xs text-muted mt-1">
                    <span>{STAGE_LABELS['submitted']}</span>
                    <span>{STAGE_LABELS['published']}</span>
                  </div>
                </div>

                {/* Expanded Timeline */}
                {isOpen && (
                  <div className="border-t border-border p-5 bg-paper/30">
                    {m.synopsis && (
                      <p className="text-sm text-muted mb-4 bg-white rounded-lg p-3 border border-border">{m.synopsis}</p>
                    )}
                    <h3 className="text-xs font-mono uppercase tracking-wider text-muted mb-3">স্টেজ ইতিহাস</h3>
                    <StageTimeline logs={m.stageLogs || []} />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
