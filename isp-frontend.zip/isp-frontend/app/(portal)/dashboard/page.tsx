'use client'
import { useAuthorDashboard } from '@/lib/hooks'
import LoadingSpinner from '@/components/shared/LoadingSpinner'
import { AuthorBadge, StageBadge, PaymentBadge } from '@/components/shared/Badge'
import { formatCurrency, formatDate } from '@/lib/utils'
import { STAGE_LABELS, STAGE_ORDER } from '@/lib/utils'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import type { ManuscriptStage } from '@/types'

export default function PortalDashboard() {
  const { data, loading } = useAuthorDashboard()

  if (loading) return <LoadingSpinner />
  if (!data) return null

  const { author, manuscripts, invoices, financials } = data

  return (
    <div className="animate-fade-in space-y-6">
      {/* Welcome */}
      <div className="card p-6 bg-gradient-to-r from-ink to-teal border-gold">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-gold text-xs font-mono uppercase tracking-widest">স্বাগতম</p>
            <h1 className="text-white text-2xl font-bold font-display mt-1">{author?.fullName}</h1>
            <p className="text-white/50 font-mono text-sm mt-1">{author?.authorCode}</p>
          </div>
          <div className="text-right">
            <AuthorBadge status={author?.badgeStatus} />
            <p className="text-white/40 text-xs mt-2">{author?.email}</p>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <SummaryCard icon="📚" label="পাণ্ডুলিপি" value={manuscripts?.length ?? 0} />
        <SummaryCard icon="📗" label="প্রকাশিত" value={manuscripts?.filter((m: any) => m.isPublished).length ?? 0} color="text-teal" />
        <SummaryCard icon="🧾" label="ইনভয়েস" value={invoices?.length ?? 0} />
        <SummaryCard icon="💰" label="বকেয়া" value={financials ? formatCurrency(financials.balanceDue) : '৳ ০'} color={financials?.balanceDue > 0 ? 'text-rust' : 'text-teal'} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        {/* Latest Manuscripts */}
        <div className="card p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-bold text-ink">সাম্প্রতিক পাণ্ডুলিপি</h2>
            <Link href="/portal/dashboard/manuscripts" className="text-xs text-gold font-semibold flex items-center gap-1">সব দেখুন <ArrowRight size={12} /></Link>
          </div>
          {!manuscripts?.length ? (
            <p className="text-muted text-sm text-center py-4">কোনো পাণ্ডুলিপি নেই।</p>
          ) : (
            <div className="space-y-3">
              {manuscripts.slice(0, 3).map((m: any) => (
                <div key={m.id} className="flex justify-between items-center py-2 border-b border-border/50 last:border-0">
                  <div>
                    <p className="font-semibold text-sm text-ink line-clamp-1">{m.title}</p>
                    <p className="text-xs text-muted mt-0.5">{formatDate(m.createdAt)}</p>
                  </div>
                  <StageBadge stage={m.currentStage} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Financials */}
        <div className="card p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-bold text-ink">আর্থিক সারসংক্ষেপ</h2>
            <Link href="/portal/dashboard/financials" className="text-xs text-gold font-semibold flex items-center gap-1">বিস্তারিত <ArrowRight size={12} /></Link>
          </div>
          {!financials ? (
            <p className="text-muted text-sm text-center py-4">কোনো আর্থিক রেকর্ড নেই।</p>
          ) : (
            <div className="space-y-3">
              <FinRow label="মোট চুক্তি" value={formatCurrency(financials.totalDeal)} />
              <FinRow label="পরিশোধিত" value={formatCurrency(financials.advancePaid)} color="text-teal" />
              <FinRow label="কর্তন" value={formatCurrency(financials.deductions)} color="text-rust" />
              <div className="border-t border-border pt-3">
                <FinRow
                  label="বকেয়া"
                  value={formatCurrency(Math.abs(financials.balanceDue))}
                  color={financials.balanceDue > 0 ? 'text-rust font-bold' : 'text-teal font-bold'}
                  note={financials.balanceDue < 0 ? '(প্রকাশক দেবেন)' : undefined}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Latest Invoice */}
      {invoices?.length > 0 && (
        <div className="card p-5">
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-bold text-ink">সর্বশেষ ইনভয়েস</h2>
            <Link href="/portal/dashboard/invoices" className="text-xs text-gold font-semibold flex items-center gap-1">সব দেখুন <ArrowRight size={12} /></Link>
          </div>
          <div className="flex items-center justify-between bg-paper rounded-lg p-4 border border-border">
            <div>
              <p className="font-mono text-sm font-bold text-gold">{invoices[0].invoiceNumber}</p>
              <p className="text-xs text-muted mt-1">{formatDate(invoices[0].createdAt)}</p>
            </div>
            <div className="text-right">
              <p className="font-mono font-bold text-ink">{formatCurrency(invoices[0].amount)}</p>
              <div className="mt-1"><PaymentBadge status={invoices[0].paymentStatus} /></div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function SummaryCard({ icon, label, value, color }: { icon: string; label: string; value: any; color?: string }) {
  return (
    <div className="card p-4 text-center">
      <div className="text-2xl mb-1">{icon}</div>
      <p className={`text-xl font-bold font-display ${color || 'text-ink'}`}>{value}</p>
      <p className="text-muted text-xs mt-0.5">{label}</p>
    </div>
  )
}

function FinRow({ label, value, color, note }: { label: string; value: string; color?: string; note?: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-muted">{label}</span>
      <span className={`font-mono ${color || 'text-ink'}`}>{value}{note && <span className="text-xs ml-1">{note}</span>}</span>
    </div>
  )
}
